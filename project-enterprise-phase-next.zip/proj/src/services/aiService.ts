/**
 * AI Service — Unified interface for both mock and real LLM responses
 * Falls back to intelligent mock when no API key is configured
 */

import type { ChatMessage, FileNode } from '../store/useStore';
import { useAIStore } from '../store/aiStore';
import { streamAgentResponse, parseFileChanges } from '../core/agents';
import type { AgentContext, FileChange } from '../core/agents/types';
import { generateId } from './../shared/utils/id';

function uid() { return generateId(); }

function flattenFiles(nodes: FileNode[]): { path: string; content: string; language: string }[] {
  const r: { path: string; content: string; language: string }[] = [];
  for (const n of nodes) {
    if (n.type === 'file') r.push({ path: n.path, content: n.content || '', language: n.language || '' });
    if (n.children) r.push(...flattenFiles(n.children));
  }
  return r;
}

// ─── Build agent context from current state ───
function buildContext(userMessage: string, files: FileNode[], activeFile: FileNode | null, history: ChatMessage[]): AgentContext {
  return {
    projectFiles: flattenFiles(files),
    activeFile: activeFile ? { path: activeFile.path, content: activeFile.content || '', language: activeFile.language || '' } : undefined,
    conversationHistory: history.slice(-10).map(m => ({ role: m.role, content: m.content })),
    userRequest: userMessage,
  };
}

// ─── Streaming AI Response (Real LLM) ───
export async function* streamAIResponse(
  userMessage: string,
  files: FileNode[],
  activeFile: FileNode | null,
  history: ChatMessage[],
  signal?: AbortSignal
): AsyncGenerator<{ type: 'text' | 'file_changes' | 'thinking' | 'error' | 'done'; content?: string; fileChanges?: FileChange[] }> {
  const { config, isReadyToChat } = useAIStore.getState();
  const isConfigured = isReadyToChat();

  if (!isConfigured) {
    // Fallback to mock
    const response = await getMockResponse(userMessage, files, activeFile);
    // Simulate streaming by yielding char by char
    for (let i = 0; i < response.length; i += 3) {
      yield { type: 'text', content: response.slice(i, i + 3) };
      await new Promise(r => setTimeout(r, 8));
    }
    const fc = parseFileChanges(response);
    if (fc.length > 0) yield { type: 'file_changes', fileChanges: fc };
    yield { type: 'done' };
    return;
  }

  const ctx = buildContext(userMessage, files, activeFile, history);

  for await (const action of streamAgentResponse(ctx, config, signal)) {
    switch (action.type) {
      case 'thinking':
        yield { type: 'thinking', content: action.thinking };
        break;
      case 'message':
        yield { type: 'text', content: action.message };
        break;
      case 'file_change':
        yield { type: 'file_changes', fileChanges: action.fileChanges };
        break;
      case 'error':
        yield { type: 'error', content: action.message };
        break;
      case 'complete':
        yield { type: 'done' };
        break;
    }
  }
}

// ─── Legacy non-streaming interface (for compatibility) ───
export async function processAIMessage(
  userMessage: string,
  files: FileNode[],
  activeFile: FileNode | null
): Promise<ChatMessage> {
  const { config, isReadyToChat: _isReady } = useAIStore.getState();

  let content: string;
  if (!_isReady()) {
    content = await getMockResponse(userMessage, files, activeFile);
  } else {
    const { agentChat } = await import('../core/agents');
    const ctx = buildContext(userMessage, files, activeFile, []);
    const result = await agentChat(ctx, config);
    content = result.content;
  }

  return {
    id: uid(),
    role: 'assistant',
    content,
    timestamp: Date.now(),
  };
}

// ─── Intelligent Mock Responses (when no API key) ───
async function getMockResponse(query: string, _files: FileNode[], activeFile: FileNode | null): Promise<string> {
  await new Promise(r => setTimeout(r, 300 + Math.random() * 500));
  const q = query.toLowerCase();

  if (/^(merhaba|selam|hey|hi|hello)/i.test(q.trim())) {
    return "👋 **Merhaba! Ben KodYap AI asistanınız.**\n\n🆓 **Ücretsiz Başlayın — API Anahtarı Gerekmez!**\n\n⚙️ AI Ayarları'ndan provider seçin:\n\n**Ücretsiz (API key gerektirmez):**\n- 🌸 **Pollinations AI** — GPT-4o, Llama, Mistral, DeepSeek (ANAHTAR YOK)\n- 🖥️ **Ollama** — Tamamen yerel, internet yok\n\n**Ücretsiz kota ile:**\n- ⚡ **Groq** — 14.400 istek/gün, ultra hızlı\n- 🔵 **Google Gemini** — 1M context, hızlı\n- 🟠 **OpenRouter** — 50+ ücretsiz model\n- 🤝 **Together AI** — Ücretsiz modeller\n- 🤗 **HuggingFace** — Açık kaynak modeller\n\n**Ücretli:**\n- 🟢 OpenAI GPT-4o | 🟣 Anthropic Claude\n\n🚀 Hadi başlayalım!";
  }

  if (/login|giriş\s*form|oturum/i.test(q)) {
    return "İşte profesyonel bir giriş formu:\n\n```tsx // filepath: /src/components/LoginForm.tsx\nimport React, { useState } from 'react';\n\nexport default function LoginForm() {\n  const [email, setEmail] = useState('');\n  const [sifre, setSifre] = useState('');\n  const [loading, setLoading] = useState(false);\n  const [hata, setHata] = useState('');\n\n  const submit = async (e: React.FormEvent) => {\n    e.preventDefault();\n    if (!email || !sifre) { setHata('Tüm alanları doldurun'); return; }\n    setHata(''); setLoading(true);\n    await new Promise(r => setTimeout(r, 1500));\n    setLoading(false);\n  };\n\n  return (\n    <div className=\"min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4\">\n      <form onSubmit={submit} className=\"w-full max-w-md bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-8 space-y-5\">\n        <h1 className=\"text-2xl font-bold text-white text-center\">Hoş Geldiniz</h1>\n        {hata && <div className=\"bg-red-500/10 border border-red-500/20 text-red-400 px-4 py-2 rounded-xl text-sm\">{hata}</div>}\n        <div>\n          <label className=\"block text-sm text-gray-300 mb-1\">E-posta</label>\n          <input type=\"email\" value={email} onChange={e => setEmail(e.target.value)}\n            className=\"w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none\" placeholder=\"ornek@email.com\" />\n        </div>\n        <div>\n          <label className=\"block text-sm text-gray-300 mb-1\">Şifre</label>\n          <input type=\"password\" value={sifre} onChange={e => setSifre(e.target.value)}\n            className=\"w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none\" placeholder=\"••••••••\" />\n        </div>\n        <button type=\"submit\" disabled={loading}\n          className=\"w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 rounded-xl font-medium disabled:opacity-50\">\n          {loading ? 'Giriş yapılıyor...' : 'Giriş Yap'}\n        </button>\n      </form>\n    </div>\n  );\n}\n```\n\n✅ **LoginForm.tsx** oluşturuldu! Glassmorphism tasarım, doğrulama, loading state.";
  }

  if (/buton|button/i.test(q)) {
    return "Modern Button bileşeni:\n\n```tsx // filepath: /src/components/Button.tsx\nimport React from 'react';\n\ntype Variant = 'primary' | 'secondary' | 'danger' | 'ghost';\n\ninterface Props extends React.ButtonHTMLAttributes<HTMLButtonElement> {\n  variant?: Variant; loading?: boolean; icon?: React.ReactNode;\n}\n\nconst styles: Record<Variant, string> = {\n  primary: 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/20',\n  secondary: 'bg-gray-700 hover:bg-gray-600 text-white',\n  danger: 'bg-red-600 hover:bg-red-700 text-white',\n  ghost: 'hover:bg-white/10 text-gray-300',\n};\n\nexport const Button: React.FC<Props> = ({ variant='primary', loading, icon, children, className='', ...rest }) => (\n  <button className={['inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl font-medium text-sm transition-all active:scale-95 disabled:opacity-50', styles[variant], className].join(' ')} disabled={rest.disabled || loading} {...rest}>\n    {loading ? <span className=\"w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin\" /> : icon}\n    {children}\n  </button>\n);\n```\n\n✅ **Button.tsx** — 4 varyant, loading spinner, ikon, active scale.";
  }

  if (/navbar|menü|header/i.test(q)) {
    return "Responsive Navbar:\n\n```tsx // filepath: /src/components/Navbar.tsx\nimport React, { useState } from 'react';\n\nexport default function Navbar() {\n  const [open, setOpen] = useState(false);\n  return (\n    <nav className=\"bg-gray-900/95 backdrop-blur-xl border-b border-white/5 sticky top-0 z-50\">\n      <div className=\"max-w-7xl mx-auto px-4 flex items-center justify-between h-16\">\n        <a href=\"#\" className=\"text-xl font-bold text-white\">⚡ KodYap</a>\n        <div className=\"hidden md:flex items-center gap-6\">\n          {['Ana Sayfa','Hakkında','Blog','İletişim'].map(l => <a key={l} href=\"#\" className=\"text-gray-300 hover:text-white text-sm\">{l}</a>)}\n          <button className=\"bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-medium\">Başla</button>\n        </div>\n        <button className=\"md:hidden text-white\" onClick={() => setOpen(!open)}>{open ? '✕' : '☰'}</button>\n      </div>\n      {open && <div className=\"md:hidden p-4 space-y-2 border-t border-white/5\">\n        {['Ana Sayfa','Hakkında','Blog','İletişim'].map(l => <a key={l} href=\"#\" className=\"block py-2 text-gray-300\">{l}</a>)}\n      </div>}\n    </nav>\n  );\n}\n```\n\n✅ **Navbar.tsx** — Sticky, backdrop-blur, responsive hamburger.";
  }

  if (/todo|yapılacak|görev/i.test(q)) {
    return "Todo uygulaması:\n\n```tsx // filepath: /src/components/TodoApp.tsx\nimport React, { useState } from 'react';\n\ninterface Todo { id: number; text: string; done: boolean; }\n\nexport default function TodoApp() {\n  const [todos, setTodos] = useState<Todo[]>([]);\n  const [input, setInput] = useState('');\n\n  const add = () => { if (!input.trim()) return; setTodos([{ id: Date.now(), text: input, done: false }, ...todos]); setInput(''); };\n\n  return (\n    <div className=\"min-h-screen bg-gray-950 flex justify-center p-4 pt-20\">\n      <div className=\"w-full max-w-lg\">\n        <h1 className=\"text-3xl font-bold text-white mb-6\">✅ Görevlerim</h1>\n        <div className=\"flex gap-2 mb-4\">\n          <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key==='Enter' && add()}\n            className=\"flex-1 bg-gray-900 border border-gray-800 rounded-xl px-4 py-3 text-white outline-none focus:border-blue-500\" placeholder=\"Yeni görev...\" />\n          <button onClick={add} className=\"bg-blue-600 text-white px-5 rounded-xl font-medium\">Ekle</button>\n        </div>\n        <div className=\"space-y-2\">\n          {todos.map(t => (\n            <div key={t.id} className={\"flex items-center gap-3 bg-gray-900 border border-gray-800 p-4 rounded-xl group \" + (t.done ? 'opacity-50' : '')}>\n              <button onClick={() => setTodos(todos.map(x => x.id === t.id ? { ...x, done: !x.done } : x))}\n                className={\"w-5 h-5 rounded-full border-2 flex-shrink-0 \" + (t.done ? 'bg-green-500 border-green-500' : 'border-gray-600')} />\n              <span className={\"flex-1 \" + (t.done ? 'line-through text-gray-500' : 'text-white')}>{t.text}</span>\n              <button onClick={() => setTodos(todos.filter(x => x.id !== t.id))} className=\"text-gray-600 hover:text-red-400 opacity-0 group-hover:opacity-100\">✕</button>\n            </div>\n          ))}\n        </div>\n      </div>\n    </div>\n  );\n}\n```\n\n✅ **TodoApp.tsx** — Ekleme, silme, tamamlama, animasyonlar.";
  }

  if (/dashboard|pano|admin/i.test(q)) {
    return "Dashboard:\n\n```tsx // filepath: /src/components/Dashboard.tsx\nimport React from 'react';\n\nexport default function Dashboard() {\n  const stats = [\n    { label: 'Kullanıcı', value: '12,847', icon: '👥', change: '+12.5%' },\n    { label: 'Gelir', value: '₺284K', icon: '💰', change: '+8.2%' },\n    { label: 'Sipariş', value: '1,429', icon: '📦', change: '+23.1%' },\n    { label: 'Dönüşüm', value: '%4.8', icon: '📈', change: '+2.4%' },\n  ];\n  return (\n    <div className=\"min-h-screen bg-gray-950 text-white p-4 md:p-8\">\n      <div className=\"max-w-7xl mx-auto\">\n        <h1 className=\"text-2xl font-bold mb-8\">Dashboard</h1>\n        <div className=\"grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8\">\n          {stats.map((s, i) => (\n            <div key={i} className=\"bg-gray-900 border border-gray-800 rounded-2xl p-5\">\n              <div className=\"flex justify-between mb-3\"><span className=\"text-2xl\">{s.icon}</span><span className=\"text-green-400 text-xs\">{s.change}</span></div>\n              <p className=\"text-2xl font-bold\">{s.value}</p>\n              <p className=\"text-gray-400 text-sm mt-1\">{s.label}</p>\n            </div>\n          ))}\n        </div>\n      </div>\n    </div>\n  );\n}\n```\n\n✅ **Dashboard.tsx** — İstatistik kartları, responsive grid.";
  }

  if (/açıkla|explain|ne\s*yapar/i.test(q) && activeFile) {
    return `📖 **\`${activeFile.name}\` Analizi:**\n\n\`\`\`${activeFile.language || ''}\n${(activeFile.content || '').slice(0, 600)}${(activeFile.content || '').length > 600 ? '\n// ...' : ''}\n\`\`\`\n\n**Bilgiler:**\n- 📄 Dil: ${activeFile.language || 'bilinmiyor'}\n- 📏 ${(activeFile.content || '').length} karakter, ${(activeFile.content || '').split('\n').length} satır\n\n💡 **Gerçek AI analizi için** ⚙️ AI Ayarları'ndan API anahtarınızı girin.`;
  }

  if (/form|iletişim|contact/i.test(q)) {
    return "İletişim formu:\n\n```tsx // filepath: /src/components/ContactForm.tsx\nimport React, { useState } from 'react';\n\nexport default function ContactForm() {\n  const [form, setForm] = useState({ isim: '', email: '', mesaj: '' });\n  const [ok, setOk] = useState(false);\n  if (ok) return <div className=\"text-center text-white py-20\"><p className=\"text-5xl mb-4\">✅</p><h2 className=\"text-2xl font-bold\">Gönderildi!</h2></div>;\n  return (\n    <form onSubmit={e => { e.preventDefault(); setOk(true); }} className=\"w-full max-w-lg bg-gray-900 border border-gray-800 rounded-2xl p-8 space-y-5 mx-auto\">\n      <h2 className=\"text-2xl font-bold text-white\">İletişim</h2>\n      <input value={form.isim} onChange={e=>setForm({...form,isim:e.target.value})} placeholder=\"İsim\" className=\"w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-2.5 text-white outline-none\" />\n      <input value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder=\"E-posta\" className=\"w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-2.5 text-white outline-none\" />\n      <textarea value={form.mesaj} onChange={e=>setForm({...form,mesaj:e.target.value})} rows={4} placeholder=\"Mesaj\" className=\"w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-2.5 text-white outline-none resize-none\" />\n      <button className=\"w-full bg-blue-600 text-white py-3 rounded-xl font-medium\">Gönder</button>\n    </form>\n  );\n}\n```\n\n✅ **ContactForm.tsx** — Doğrulama, başarı ekranı, modern tasarım.";
  }

  if (/hata|bug|sorun|error|düzelt/i.test(q)) {
    return "🔍 **Hata Ayıklama Asistanı**\n\n" + (activeFile ? "Açık dosya: `" + activeFile.name + "`\n\n" : "") + "**Yaygın Hatalar:**\n\n| Hata | Çözüm |\n|------|-------|\n| `Cannot find module` | `npm install` çalıştırın |\n| `Type error` | TypeScript tiplerini kontrol edin |\n| `Unexpected token` | Söz dizimi kontrol edin |\n| `CORS error` | API'de CORS ayarları |\n\n💡 **Gerçek AI hata çözümü için** ⚙️ AI Ayarları'ndan API anahtarınızı girin.\nHata mesajınızı paylaşın, analiz edeyim!";
  }

  // Default
  return "🤖 \"" + query + "\" ile ilgili yardımcı olabilirim!\n\n**Kullanılabilir komutlar:**\n- `buton`, `navbar`, `form`, `todo`, `dashboard`, `login formu`\n- `bu dosyayı açıkla`, `hata ayıkla`\n\n🌸 **API anahtarı olmadan da kullanabilirsiniz:**\n⚙️ AI Ayarları → **Pollinations AI** seçin (ücretsiz, anahtar gerekmez)!";
}
